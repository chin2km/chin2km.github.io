self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f223ded8eb9d04a4430cd84d77dbf666",
    "url": "/index.html"
  },
  {
    "revision": "1dfc20b0ce7bc395b175",
    "url": "/main.5f013347126e75da2a56.js"
  },
  {
    "revision": "1dfc20b0ce7bc395b175",
    "url": "/main.css"
  }
]);