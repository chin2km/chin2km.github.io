self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ba0512490a4041bbd7e18a1e59184b69",
    "url": "/index.html"
  },
  {
    "revision": "15c3d7f44d21682e0f04",
    "url": "/main.css"
  },
  {
    "revision": "15c3d7f44d21682e0f04",
    "url": "/main.fc966ba5345f12a9880d.js"
  }
]);