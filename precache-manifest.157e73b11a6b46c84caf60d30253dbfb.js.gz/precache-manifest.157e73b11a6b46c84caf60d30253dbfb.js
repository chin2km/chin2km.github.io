self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "33816d3f6d0df95df07a7db5e5e256da",
    "url": "/index.html"
  },
  {
    "revision": "66a8dafc1789c858d81b",
    "url": "/main.88283df698140694043c.js"
  },
  {
    "revision": "66a8dafc1789c858d81b",
    "url": "/main.css"
  }
]);