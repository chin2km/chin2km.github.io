self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b1b96fcc90a15ee73b7f8b0e2bb4721f",
    "url": "/index.html"
  },
  {
    "revision": "d76cdf6d9d87fe33892f",
    "url": "/main.b681e2547d164f615054.js"
  },
  {
    "revision": "d76cdf6d9d87fe33892f",
    "url": "/main.css"
  }
]);