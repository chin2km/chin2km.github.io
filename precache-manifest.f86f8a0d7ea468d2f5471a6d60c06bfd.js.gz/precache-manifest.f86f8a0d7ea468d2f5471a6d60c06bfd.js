self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "13bff04232f020673f78",
    "url": "/bundle.js"
  },
  {
    "revision": "5b39107d3ac8977584479c1dcb9466fb",
    "url": "/index.html"
  },
  {
    "revision": "13bff04232f020673f78",
    "url": "/main.css"
  }
]);