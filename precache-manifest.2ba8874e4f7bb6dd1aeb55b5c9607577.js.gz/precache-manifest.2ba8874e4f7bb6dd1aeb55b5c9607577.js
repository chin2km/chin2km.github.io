self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d7885ca73df96f6d4f3d",
    "url": "/bundle.js"
  },
  {
    "revision": "781bac2eb957c7edb27be74a6189194d",
    "url": "/index.html"
  },
  {
    "revision": "d7885ca73df96f6d4f3d",
    "url": "/main.css"
  }
]);