self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7fb27f066b6330105bb60af443d951f8",
    "url": "/index.html"
  },
  {
    "revision": "9a08d4ffb9581a715527",
    "url": "/main.b52124ec6d1bd796900a.js"
  },
  {
    "revision": "9a08d4ffb9581a715527",
    "url": "/main.css"
  }
]);